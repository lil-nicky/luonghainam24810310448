using Bai4_3;
using System;
using System.Windows.Forms;

namespace Bai4_3
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}