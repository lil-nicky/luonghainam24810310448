using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Bai4_3
{
    // Model sản phẩm
    public class ProductModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public double Price { get; set; }
        public int Quantity { get; set; }
    }

    public partial class Form1 : Form
    {
        // BindingList theo đúng yêu cầu bài
        private BindingList<ProductModel> products =
            new BindingList<ProductModel>();

        public Form1()
        {
            InitializeComponent();

            // Gán BindingList cho DataGridView
            dataGridView1.DataSource = products;
        }

        // =========================
        // THÊM
        // =========================
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("ID phải là số!");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTen.Text))
            {
                MessageBox.Show("Vui lòng nhập tên sản phẩm!");
                return;
            }

            if (!double.TryParse(txtGia.Text, out double gia))
            {
                MessageBox.Show("Giá không hợp lệ!");
                return;
            }

            if (!int.TryParse(txtSoLuong.Text, out int soLuong))
            {
                MessageBox.Show("Số lượng không hợp lệ!");
                return;
            }

            ProductModel product = new ProductModel
            {
                Id = id,
                Name = txtTen.Text,
                Price = gia,
                Quantity = soLuong
            };

            products.Add(product);

            XoaDuLieu();
        }

        // =========================
        // XÓA
        // =========================
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            ProductModel product =
                dataGridView1.CurrentRow.DataBoundItem
                as ProductModel;

            if (product != null)
            {
                products.Remove(product);
                XoaDuLieu();
            }
        }

        // =========================
        // SỬA
        // =========================
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            ProductModel product =
                dataGridView1.CurrentRow.DataBoundItem
                as ProductModel;

            if (product == null)
                return;

            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("ID phải là số!");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTen.Text))
            {
                MessageBox.Show("Vui lòng nhập tên sản phẩm!");
                return;
            }

            if (!double.TryParse(txtGia.Text, out double gia))
            {
                MessageBox.Show("Giá không hợp lệ!");
                return;
            }

            if (!int.TryParse(txtSoLuong.Text, out int soLuong))
            {
                MessageBox.Show("Số lượng không hợp lệ!");
                return;
            }

            product.Id = id;
            product.Name = txtTen.Text;
            product.Price = gia;
            product.Quantity = soLuong;

            // Cập nhật lại DataGridView
            dataGridView1.Refresh();

            XoaDuLieu();
        }

        // =========================
        // CLICK VÀO DÒNG
        // =========================
        private void dataGridView1_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            ProductModel product =
                dataGridView1.Rows[e.RowIndex].DataBoundItem
                as ProductModel;

            if (product != null)
            {
                txtId.Text = product.Id.ToString();
                txtTen.Text = product.Name;
                txtGia.Text = product.Price.ToString();
                txtSoLuong.Text = product.Quantity.ToString();
            }
        }

        // =========================
        // XÓA Ô NHẬP
        // =========================
        private void XoaDuLieu()
        {
            txtId.Clear();
            txtTen.Clear();
            txtGia.Clear();
            txtSoLuong.Clear();

            txtId.Focus();
        }
    }
}