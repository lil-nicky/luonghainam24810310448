﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4._3
{
    internal class Class1
    {
    }
}
