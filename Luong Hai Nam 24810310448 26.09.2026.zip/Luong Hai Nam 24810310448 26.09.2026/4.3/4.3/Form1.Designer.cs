﻿namespace Bai4_3
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label lblGia;
        private System.Windows.Forms.Label lblSoLuong;

        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.TextBox txtSoLuong;

        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;

        private System.Windows.Forms.DataGridView dataGridView1;

        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQuantity;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.lblId = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.lblGia = new System.Windows.Forms.Label();
            this.lblSoLuong = new System.Windows.Forms.Label();

            this.txtId = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();

            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();

            this.dataGridView1 =
                new System.Windows.Forms.DataGridView();

            this.colId =
                new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.colName =
                new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.colPrice =
                new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.colQuantity =
                new System.Windows.Forms.DataGridViewTextBoxColumn();

            ((System.ComponentModel.ISupportInitialize)
                this.dataGridView1).BeginInit();

            this.SuspendLayout();

            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location =
                new System.Drawing.Point(25, 25);
            this.lblId.Name = "lblId";
            this.lblId.Text = "ID:";

            // 
            // txtId
            // 
            this.txtId.Location =
                new System.Drawing.Point(120, 20);
            this.txtId.Name = "txtId";
            this.txtId.Size =
                new System.Drawing.Size(220, 23);

            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Location =
                new System.Drawing.Point(25, 65);
            this.lblTen.Name = "lblTen";
            this.lblTen.Text = "Tên sản phẩm:";

            // 
            // txtTen
            // 
            this.txtTen.Location =
                new System.Drawing.Point(120, 60);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size =
                new System.Drawing.Size(220, 23);

            // 
            // lblGia
            // 
            this.lblGia.AutoSize = true;
            this.lblGia.Location =
                new System.Drawing.Point(25, 105);
            this.lblGia.Name = "lblGia";
            this.lblGia.Text = "Giá:";

            // 
            // txtGia
            // 
            this.txtGia.Location =
                new System.Drawing.Point(120, 100);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size =
                new System.Drawing.Size(220, 23);

            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location =
                new System.Drawing.Point(25, 145);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Text = "Số lượng:";

            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location =
                new System.Drawing.Point(120, 140);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size =
                new System.Drawing.Size(220, 23);

            // 
            // btnThem
            // 
            this.btnThem.Location =
                new System.Drawing.Point(370, 20);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size =
                new System.Drawing.Size(100, 35);
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click +=
                new System.EventHandler(this.btnThem_Click);

            // 
            // btnSua
            // 
            this.btnSua.Location =
                new System.Drawing.Point(370, 65);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size =
                new System.Drawing.Size(100, 35);
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click +=
                new System.EventHandler(this.btnSua_Click);

            // 
            // btnXoa
            // 
            this.btnXoa.Location =
                new System.Drawing.Point(370, 110);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size =
                new System.Drawing.Size(100, 35);
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click +=
                new System.EventHandler(this.btnXoa_Click);

            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            this.dataGridView1.Columns.AddRange(
                new System.Windows.Forms.DataGridViewColumn[]
                {
                    this.colId,
                    this.colName,
                    this.colPrice,
                    this.colQuantity
                });

            this.dataGridView1.Location =
                new System.Drawing.Point(25, 190);

            this.dataGridView1.Name =
                "dataGridView1";

            this.dataGridView1.Size =
                new System.Drawing.Size(600, 250);

            this.dataGridView1.CellClick +=
                new System.Windows.Forms.DataGridViewCellEventHandler(
                    this.dataGridView1_CellClick);

            // 
            // colId
            // 
            this.colId.HeaderText = "ID";
            this.colId.DataPropertyName = "Id";
            this.colId.Name = "colId";
            this.colId.Width = 70;

            // 
            // colName
            // 
            this.colName.HeaderText = "Tên sản phẩm";
            this.colName.DataPropertyName = "Name";
            this.colName.Name = "colName";
            this.colName.Width = 200;

            // 
            // colPrice
            // 
            this.colPrice.HeaderText = "Giá";
            this.colPrice.DataPropertyName = "Price";
            this.colPrice.Name = "colPrice";
            this.colPrice.Width = 130;

            // 
            // colQuantity
            // 
            this.colQuantity.HeaderText = "Số lượng";
            this.colQuantity.DataPropertyName = "Quantity";
            this.colQuantity.Name = "colQuantity";
            this.colQuantity.Width = 100;

            // 
            // Form1
            // 
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(7F, 15F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(660, 470);

            this.Controls.Add(this.lblId);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.lblGia);
            this.Controls.Add(this.lblSoLuong);

            this.Controls.Add(this.txtId);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.txtGia);
            this.Controls.Add(this.txtSoLuong);

            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnXoa);

            this.Controls.Add(this.dataGridView1);

            this.Name = "Form1";
            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.Text =
                "Quản lý sản phẩm";

            ((System.ComponentModel.ISupportInitialize)
                this.dataGridView1).EndInit();

            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}