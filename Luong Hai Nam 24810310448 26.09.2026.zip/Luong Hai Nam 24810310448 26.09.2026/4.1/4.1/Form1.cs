using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace Bai4_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Dùng chung cho các nút số 0 -> 9
        private void btnNum_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            txtDisplay.Text += btn.Text;
        }

        // Nút +
        private void btnCong_Click(object sender, EventArgs e)
        {
            ThemPhepToan("+");
        }

        // Nút -
        private void btnTru_Click(object sender, EventArgs e)
        {
            ThemPhepToan("-");
        }

        // Nút *
        private void btnNhan_Click(object sender, EventArgs e)
        {
            ThemPhepToan("*");
        }

        // Nút /
        private void btnChia_Click(object sender, EventArgs e)
        {
            ThemPhepToan("/");
        }

        // Thêm phép toán
        private void ThemPhepToan(string phepToan)
        {
            if (txtDisplay.Text == "")
                return;

            char kyTuCuoi = txtDisplay.Text[txtDisplay.Text.Length - 1];

            // Nếu vừa có phép toán thì thay bằng phép toán mới
            if (kyTuCuoi == '+' ||
                kyTuCuoi == '-' ||
                kyTuCuoi == '*' ||
                kyTuCuoi == '/')
            {
                txtDisplay.Text =
                    txtDisplay.Text.Substring(
                        0,
                        txtDisplay.Text.Length - 1);
            }

            txtDisplay.Text += phepToan;
        }

        // Nút C
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        // Nút =
        private void btnBang_Click(object sender, EventArgs e)
        {
            try
            {
                string bieuThuc = txtDisplay.Text;

                if (string.IsNullOrWhiteSpace(bieuThuc))
                    return;

                // Nếu cuối biểu thức là phép toán thì bỏ nó
                char cuoi = bieuThuc[bieuThuc.Length - 1];

                if (cuoi == '+' ||
                    cuoi == '-' ||
                    cuoi == '*' ||
                    cuoi == '/')
                {
                    bieuThuc =
                        bieuThuc.Substring(
                            0,
                            bieuThuc.Length - 1);
                }

                double ketQua = TinhBieuThuc(bieuThuc);

                txtDisplay.Text =
                    ketQua.ToString(CultureInfo.InvariantCulture);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show(
                    "Không thể chia cho 0!",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                txtDisplay.Clear();
            }
            catch
            {
                MessageBox.Show(
                    "Phép tính không hợp lệ!",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                txtDisplay.Clear();
            }
        }

        // Tính biểu thức
        private double TinhBieuThuc(string bieuThuc)
        {
            List<double> so = new List<double>();
            List<char> toanTu = new List<char>();

            string soHienTai = "";

            // Tách số và phép toán
            for (int i = 0; i < bieuThuc.Length; i++)
            {
                char c = bieuThuc[i];

                if (char.IsDigit(c) || c == '.')
                {
                    soHienTai += c;
                }
                else if (c == '+' ||
                         c == '-' ||
                         c == '*' ||
                         c == '/')
                {
                    if (soHienTai == "")
                        throw new Exception();

                    so.Add(
                        double.Parse(
                            soHienTai,
                            CultureInfo.InvariantCulture));

                    toanTu.Add(c);

                    soHienTai = "";
                }
                else
                {
                    throw new Exception();
                }
            }

            if (soHienTai == "")
                throw new Exception();

            so.Add(
                double.Parse(
                    soHienTai,
                    CultureInfo.InvariantCulture));

            // =====================================
            // Tính * và /
            // =====================================

            for (int i = 0; i < toanTu.Count;)
            {
                if (toanTu[i] == '*' ||
                    toanTu[i] == '/')
                {
                    double a = so[i];
                    double b = so[i + 1];
                    double ketQua;

                    if (toanTu[i] == '*')
                    {
                        ketQua = a * b;
                    }
                    else
                    {
                        if (b == 0)
                            throw new DivideByZeroException();

                        ketQua = a / b;
                    }

                    // Gộp kết quả vào danh sách
                    so[i] = ketQua;
                    so.RemoveAt(i + 1);
                    toanTu.RemoveAt(i);
                }
                else
                {
                    i++;
                }
            }

            // =====================================
            // Tính + và -
            // =====================================

            double ketQuaCuoi = so[0];

            for (int i = 0; i < toanTu.Count; i++)
            {
                if (toanTu[i] == '+')
                {
                    ketQuaCuoi += so[i + 1];
                }
                else if (toanTu[i] == '-')
                {
                    ketQuaCuoi -= so[i + 1];
                }
            }

            return ketQuaCuoi;
        }
    }
}